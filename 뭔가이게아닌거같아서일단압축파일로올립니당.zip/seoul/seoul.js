// npm i express
// npm i mysql
// 공용 서버 만들어야 업로드 가능할 것 같습니다.

var mysql      = require('mysql');
var connection = mysql.createConnection({
  host     : 'localhost',
  user     : 'root',
  password : '0000',
  database : 'marketcr' //db이름
});
 
connection.connect();
//                              ▽테이블이름
connection.query('SELECT * from regiontable', function (error, results, fields) {
  if (error) throw error;
  console.log('users: ', results);
});
 
connection.end();